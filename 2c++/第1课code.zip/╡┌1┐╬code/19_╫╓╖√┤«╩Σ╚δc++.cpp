#include <iostream>
using namespace std;
int main() {
	char str[10] = { 0 };
	cin.getline(str, sizeof(str));
	cout << str << endl;
	return 0;
}

