//(2):typedef using
typedef int int_32;
using int32 = int;
void f(int32 a, int32 *const p);
int_32 f(int_32 a, int *p);