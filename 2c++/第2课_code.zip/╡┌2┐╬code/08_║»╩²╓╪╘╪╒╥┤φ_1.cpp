//(1):main����
int main() { return 0; }
int main(int argc, char* argv[]) { return 0; }