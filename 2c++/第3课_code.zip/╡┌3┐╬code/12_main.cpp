///����
#include <iostream>
#include "myString.h"
using namespace std;

int main() {
	myString s1;
	return 0;
}